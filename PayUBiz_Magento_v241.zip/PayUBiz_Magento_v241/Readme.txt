This PayUBiz Redirect plugin for Magento v2.4.1 plugin.

This plugin supports Web Browser security update for cross-site request forgery (CSRF).

Functionality wise the plugin works simalar way as it was earlier. Only difference is, it traps session cookies and inject "SameSite=None; Secure".


Pre-requisite:

- Magento 2.4.1 installation (both frontend and admin) must be running on HTTPS. 
- Self-signed certificate will also work in case of localhost or demo installations.


Steps:

1. Take a full backup of existing Magento 2.4.1 (both code and database)

2. If previously installed, disable PayU payment plugin.

3. Uninstall / Remove physical plugin files from app/code/PayUIndia

4. Upload present plugin files from the included 'upload' directory to Magento root.

5. upgrade and deploy Magento installation.

6. Login to Admin panel and enable payment plugin.



Troubleshooting:

- In case this plugin does not work properly immediately revert to old plugin or for major issues restore site from backup.

- For modifying email notification options visit Admin->Store->Configuraton->Sales->Sales Emails

- For advanced modification of email codes, vendor/magento/module-sales/Model/Order/Email/Sender/OrderSender.php

- By default, Magento sends new order confirmation mail during checkout - order confirmation. That means, for redirect payment option,
mail goes out evern before actual payment is done. 
To stop this new order email before payment, upload from "troubleshooting-neworder-email" folder to Magento root.

- cookie_httponly = On, cookie_secure=1, cookie_samesite=None to be configured in php environment.

- Magento Samesite=Lax issue fix is present. Copy included PublicCookieMetadata.php and SensitiveCookieMetadata.php to vendor\Magento\Framework\Stdlib\Cookie\

https://meetanshi.com/blog/solved-magento-2-2-7-and-2-3-admin-page-blank-issue/